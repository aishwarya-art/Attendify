// src/types.ts
export type RootStackParamList = {
    Login: undefined;
    Dashboard: undefined;
  };
  