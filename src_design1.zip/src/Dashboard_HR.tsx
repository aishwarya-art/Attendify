
import React from 'react';
import Navigation from './Navigation'; // Import the Navigation component


const Dashboard_HR: React.FC = () => {
  return (
    <div >
      <Navigation />
      <div >
        <h1>Hr Dashboard</h1>
        {/* Add other components or content here */}
      </div>
    </div>
  );
};

export default Dashboard_HR;
