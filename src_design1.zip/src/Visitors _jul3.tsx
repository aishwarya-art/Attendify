import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { View, Text, Image, StyleSheet, ScrollView, TouchableOpacity, Modal, Button, Alert } from 'react-native';
import { Formik } from 'formik';
import * as Yup from 'yup';
import { TextInput as RNTextInput } from 'react-native';
import Navigation from './Navigation'; // Import the Navigation component
import Footer from './Footer'; // Import the Footer component
import { useNavigate } from 'react-router-dom';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { FaPhone, FaHome, FaPowerOff,FaBell,FaArrowLeft } from 'react-icons/fa';
import { Keyboard, Platform } from 'react-native';

interface VisitorData {
  detected_face: string;
  first_check_in: string;
  id: string;
  email?: string;
  name?: string;
  contact?: string;
}

interface GuestData {
  detected_face: string;
  first_check_in: string;
  id: string;
  email?: string;
  first_name?: string;
  last_name?: string;
  contact?: string;
  status: number;
}

interface EmployeeData {
  id: string;
  first_name: string;
  last_name: string;
}

const Visitors: React.FC = () => {
  const [data, setData] = useState<VisitorData[]>([]);
  const [empList, setEmpList] = useState<EmployeeData[]>([]);
  const [guestList, setGuestList] = useState<GuestData[]>([]);
  const [selectedVisitor, setSelectedVisitor] = useState<VisitorData | null>(null);
  const [employeeCount, setEmployeeCount] = useState(0);
  const [visitorCount, setVisitorCount] = useState(0);
  const [totalvisitorCount, setVisitorCounts] = useState(0);
  const [visitorStatusCount, setVisitorStatusCount] = useState(0);
  const navigate = useNavigate();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isKeyboardVisible, setKeyboardVisible] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [currentPage, setCurrentPage] = useState(0);
  const itemsPerPage = 3; // Define itemsPerPage here
  const [currentGuestPage, setCurrentGuestPage] = useState(0);
  const handleLogout = async () => {
    const confirmLogout = window.confirm('Are you sure you want to logout?');
    if (confirmLogout) {
      try {
        await AsyncStorage.clear();
        navigate('/');
      } catch (error) {
        console.error('Error clearing local storage:', error);
      }
    }
  };
  const handleNavigateToVisitors = () => {
    setSelectedVisitor(null);
    navigate('/Visitors');
  };

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', () => {
      setKeyboardVisible(true);
    });
    const keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', () => {
      setKeyboardVisible(false);
    });
  
    return () => {
      keyboardDidHideListener.remove();
      keyboardDidShowListener.remove();
    };
  }, []);
  
  useEffect(() => {
    const fetchVisitorData = async () => {
      const user_id = await AsyncStorage.getItem('user_id');
      try {
        const response = await axios.get(`https://dev.techkshetra.ai/office_webApi/public/index.php/Guest/Guest_index?user_id=${user_id}`);
        setData(response.data.data);
        setVisitorCount(response.data.data.length); // Set visitor count
        console.log("Visitor data fetched:", response.data.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchVisitorData();
    const intervalId = setInterval(fetchVisitorData, 3000);

    // Cleanup interval on component unmount
    return () => clearInterval(intervalId);
  }, []);

  useEffect(() => {
    const fetchEmployeeData = async () => {
      const user_id = await AsyncStorage.getItem('user_id');
      axios.get(`https://dev.techkshetra.ai/office_webApi/public/index.php/Dashboard/getUsers?user_id=${user_id}`)
        .then(response => {
          setEmpList(response.data.data); // Set the fetched data to the state
        })
        .catch(error => console.error('Error fetching data:', error));
    };
 
    fetchEmployeeData();
    const intervalId = setInterval(fetchEmployeeData, 3000);

    // Cleanup interval on component unmount
    return () => clearInterval(intervalId);
  }, []);
  
  useEffect(() => {
    const fetchVisitorStatusData = async () => {
      const user_id = await AsyncStorage.getItem('user_id');
      try {
        const response = await axios.get(`https://dev.techkshetra.ai/office_webApi/public/index.php/Guest/Guest_Approval_status?user_id=${user_id}`);
        setGuestList(response.data.data);
        setVisitorStatusCount(response.data.data.length); // Set visitor count
        console.log("Visitor Status data fetched:", response.data.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchVisitorStatusData();
    const intervalId = setInterval(fetchVisitorStatusData, 3000);

    // Cleanup interval on component unmount
    return () => clearInterval(intervalId);
  }, []);

  useEffect(() => {
    const fetchCounts = async () => {
      const user_id = await AsyncStorage.getItem('user_id');
      try {
        const response = await axios.get(`https://dev.techkshetra.ai/office_webApi/public/index.php/Dashboard/getEmployeeCount_mobile?user_id=${user_id}`);
        console.log(response.data);
        if (response.data.status) {
          setEmployeeCount(response.data.empcount);
        } else {
          setEmployeeCount(0);
        }
      } catch (error) {
        console.error('Error fetching counts:', error);
      }
    };

    fetchCounts();
  }, []);

  useEffect(() => {
    const fetchVisitorCounts = async () => {
      const user_id = await AsyncStorage.getItem('user_id');
      try {
        const response = await axios.get(`https://dev.techkshetra.ai/office_webApi/public/index.php/Dashboard/getGuestCount_mobile?user_id=${user_id}`);
        console.log(response.data);
        if (response.data.status) {
          setVisitorCounts(response.data.guestcount);
        } else {
          setVisitorCounts(0);
        }
      } catch (error) {
        console.error('Error fetching counts:', error);
      }
    };

    // fetchVisitorCounts();
    fetchVisitorCounts();

    // Set up interval to fetch counts every 3 seconds
    const intervalId = setInterval(fetchVisitorCounts, 3000);

    // Cleanup interval on component unmount
    return () => clearInterval(intervalId);
  }, []);


  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const handleCardClick = (visitor: VisitorData) => {
    console.log("Card clicked:", visitor);
    setSelectedVisitor(visitor);
  };

  const validationSchema = Yup.object().shape({
    firstName: Yup.string()
      .matches(/^[a-zA-Z_ ]*$/, 'First name can only contain letters, underscores, and spaces')
      .required('Full name is required'),
    // lastName: Yup.string()
    //   .matches(/^[a-zA-Z_ ]*$/, 'Last name can only contain letters, underscores, and spaces')
    //   .required('Last name is required'),
    contact: Yup.string()
      .matches(/^[0-9]*$/, 'Contact number can only contain numbers')
      .required('Contact number is required')
      .min(10, 'Contact number must be at least 10 digits')
      .max(10, 'Contact number must be at most 10 digits'),
    email: Yup.string()
      .email('Invalid email format')
      .required('Email is required'),
    guestfrom: Yup.string().required('Guest from is required'),
    purpose: Yup.string().required('Purpose is required'),
    user_id: Yup.string().required('Employee selection is required'),
  });

  const handleSubmit = async (values: any) => {
    const formData = new FormData();
    formData.append('first_name', values.firstName);
    // formData.append('last_name', values.lastName);
    formData.append('purpose', values.purpose);
    formData.append('guestID', selectedVisitor!.id);
    formData.append('email', values.email);
    formData.append('contact', values.contact);
    formData.append('guestfrom', values.guestfrom);
    formData.append('user_id', values.user_id);

    try {
      const response = await axios.post(
        'https://dev.techkshetra.ai/office_webApi/public/index.php/Guest/update_guest',
        formData,
        {
          headers: {
            "Accept": "application/json",
          }
        }
      );

      if (response.status === 200) {
        setData(data.filter(visitor => visitor.id !== selectedVisitor!.id));
        console.log("Data submitted successfully:", response.data);
        Alert.alert('Success', 'Data submitted successfully');
        setSelectedVisitor(null); // Close the modal
      } else {
        console.error('Error submitting data:', response);
      }
    } catch (error) {
      console.error('Error submitting data:', error);
    }
  };


  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'short', day: '2-digit' };
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', options).replace(/ /g, ' ');
  };
  
  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-GB');
  };

  const filterInput = (value: string, pattern: RegExp) => {
    return value.replace(pattern, '');
  };
  const handleNextPage = () => {
    if ((currentPage + 1) * itemsPerPage < data.length) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handlePreviousPage = () => {
    if (currentPage > 0) {
      setCurrentPage(currentPage - 1);
    }
  };
  const handleNextGuestPage = () => {
    if ((currentGuestPage + 1) * itemsPerPage < guestList.length) {
      setCurrentGuestPage(currentGuestPage + 1);
    }
  };

  const handlePreviousGuestPage = () => {
    if (currentGuestPage > 0) {
      setCurrentGuestPage(currentGuestPage - 1);
    }
  };
  const visibleVisitors = data.slice(currentPage * itemsPerPage, (currentPage + 1) * itemsPerPage);
  const visibleGuests = guestList.slice(currentGuestPage * itemsPerPage, (currentGuestPage + 1) * itemsPerPage);
  return (
    <div> 
    <View style={styles.wrapper}>
      <Navigation />
      <View style={styles.timeContainer}>
      <View style={styles.timeContainerdiv}>
            <Text style={styles.timeText}>
            {currentTime.toLocaleDateString('en-GB', {
              day: '2-digit',
              month: 'short',
              year: 'numeric',
            })} {currentTime.toLocaleTimeString()}
    </Text>
         </View>
        </View>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.cardContainer}>
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Employees</Text>
            <Text style={styles.cardValue}>{employeeCount}</Text>
          </View>
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Visitors</Text>
            <Text style={styles.cardValue}>{totalvisitorCount}</Text>
          </View>
        </View>
        <Text>Action Required</Text>
        
       
        <ScrollView>
          {visibleVisitors.length > 0 ? (
            visibleVisitors.map((visitor, index) => (
              <TouchableOpacity key={index} onPress={() => handleCardClick(visitor)} style={styles.visitorCard}>
                <Image
                  style={styles.avatar}
                  source={{ uri: `https://vision.techkshetra.ai/faceRecognitionEngine/faces/${visitor.detected_face}` }}
                />
                <View style={styles.info}>
                  {/* <Text style={styles.text}> {visitor.first_check_in}</Text> */}
                  <Text style={styles.text}>{formatDate(visitor.first_check_in)}</Text>
                  <Text style={styles.text}>{formatTime(visitor.first_check_in)}</Text>
                </View>
              </TouchableOpacity>
            ))
          ) : (
            <View style={styles.noVisitorsCard}>
              <Text style={styles.noVisitorsText}>No visitors today!</Text>
            </View>
          )}
        </ScrollView>
       
        <View style={styles.buttonsContainer}>
  <Button title="<<" onPress={handlePreviousPage} disabled={currentPage === 0} color="rgb(152 5 5)" />
  <Button title=">>" onPress={handleNextPage} disabled={(currentPage + 1) * itemsPerPage >= data.length} color="rgb(152 5 5)" />
</View>
        <Text>Registered Visitors</Text>
       
         <ScrollView>
          {visibleGuests.length > 0 ? (
            visibleGuests.map((guest, index) => (
              // <TouchableOpacity key={index}  style={styles.visitorCard}>
              <TouchableOpacity
              key={index}
              style={[
                styles.visitorCard,
                {
                  backgroundColor:
                    guest.status == 1 ? 'rgb(224, 233, 219)' : guest.status == 2 ? 'rgb(235, 224, 224)' : '#fff',
                },
              ]}
            >
                <Image
                  style={styles.avatar}
                  source={{ uri: `https://vision.techkshetra.ai/faceRecognitionEngine/faces/${guest.detected_face}` }}
                />
                
                <View style={styles.info}>
                  <Text style={styles.visitorTitle}>{guest.first_name}</Text>
                 
                  <View style={styles.dateStatusRow}>
            <View>
              <Text style={styles.textdate}>{formatDate(guest.first_check_in)}</Text>
              <Text style={styles.textdate}>{formatTime(guest.first_check_in)}</Text>
            </View>
            <Text
              style={[
                styles.textStatus,
                { color: guest.status == 1 ? 'green' : guest.status == 2 ? 'red' : 'black' },
              ]}
            >
              <b>{guest.status == 1 ? 'Approved' : guest.status == 2 ? 'Rejected' : 'Pending'}</b>
            </Text>
          </View>
        
                </View>
              </TouchableOpacity>
            ))
          ) : (
            <View style={styles.noVisitorsCard}>
              <Text style={styles.noVisitorsText}>No visitors today!</Text>
            </View>
          )}
        </ScrollView>
       
        <View style={styles.buttonsContainer}>
  <Button title="<<" onPress={handlePreviousGuestPage} disabled={currentGuestPage === 0} color="rgb(152 5 5)" />
  <Button title=">>" onPress={handleNextGuestPage} disabled={(currentGuestPage + 1) * itemsPerPage >= guestList.length} color="rgb(152 5 5)" />
</View>
        {selectedVisitor && (
         <Modal
         animationType="slide"
         transparent={false}
         visible={!!selectedVisitor}
         onRequestClose={() => setSelectedVisitor(null)}
       >
         <ScrollView contentContainerStyle={styles.modalScrollContainer}>
           <View style={styles.modalHeader}>
             <Image
               style={styles.modalAvatar}
               source={{ uri: `https://vision.techkshetra.ai/faceRecognitionEngine/faces/${selectedVisitor.detected_face}` }}
             />
           </View>
           <View style={styles.modalContainer}>
             <Formik
               initialValues={{
                 firstName: '',
                //  lastName: '',
                 contact: '',
                 email: '',
                 guestfrom: '',
                 purpose: '',
                 user_id: '',
               }}
               validationSchema={validationSchema}
               onSubmit={handleSubmit}
             >
               {({ handleChange, handleBlur, handleSubmit, values, errors, touched, setFieldValue }) => (
                 <View style={styles.form}>
                   <RNTextInput
                     style={styles.input}
                     placeholder="Enter full name"
                     onChangeText={(value) => setFieldValue('firstName', filterInput(value, /[^a-zA-Z_ ]/g))}
                     onBlur={handleBlur('firstName')}
                     value={values.firstName}
                   />
                   {errors.firstName && touched.firstName ? (
                     <Text style={styles.errorText}>{errors.firstName}</Text>
                   ) : null}
                  
                  <RNTextInput
                    style={styles.input}
                    placeholder="Enter contact number"
                    onChangeText={(value) => setFieldValue('contact', filterInput(value, /[^0-9]/g))}
                    onBlur={handleBlur('contact')}
                    value={values.contact}
                    inputMode="tel"
                    maxLength={10}
                  />
                   {errors.contact && touched.contact ? (
                     <Text style={styles.errorText}>{errors.contact}</Text>
                   ) : null}
                   <RNTextInput
                     style={styles.input}
                     placeholder="Enter email"
                     onChangeText={handleChange('email')}
                     onBlur={handleBlur('email')}
                     value={values.email}
                     keyboardType="email-address"
                   />
                   {errors.email && touched.email ? (
                     <Text style={styles.errorText}>{errors.email}</Text>
                   ) : null}
                   <RNTextInput
                     style={styles.input}
                     placeholder="Enter from"
                     onChangeText={handleChange('guestfrom')}
                     onBlur={handleBlur('guestfrom')}
                     value={values.guestfrom}
                   />
                   {errors.guestfrom && touched.guestfrom ? (
                     <Text style={styles.errorText}>{errors.guestfrom}</Text>
                   ) : null}
                   <RNTextInput
                     style={styles.input}
                     placeholder="Enter purpose of visit"
                     onChangeText={handleChange('purpose')}
                     onBlur={handleBlur('purpose')}
                     value={values.purpose}
                     multiline
                     numberOfLines={2}
                   />
                   {errors.purpose && touched.purpose ? (
                     <Text style={styles.errorText}>{errors.purpose}</Text>
                   ) : null}
                   <View>
                     <select style={styles.select}
                       value={values.user_id}
                       onChange={handleChange('user_id')}
                       required
                     >
                       <option value="">Select an employee</option>
                       {empList.map(emp => (
                         <option key={emp.id} value={emp.id}>
                           {emp.first_name} {emp.last_name}
                         </option>
                       ))}
                     </select>
                   </View>
                   {errors.user_id && touched.user_id ? (
                     <Text style={styles.errorText}>{errors.user_id}</Text>
                   ) : null}
                   <TouchableOpacity style={styles.buttonSubmit} onPress={handleSubmit as any}>
                     <Text style={styles.buttonText}>Submit</Text>
                   </TouchableOpacity>
                 </View>
               )}
             </Formik>
           </View>
          
         </ScrollView>
         {!isKeyboardVisible && (
             <div className="footer">
               <FaArrowLeft className="footer-icon" onClick={handleNavigateToVisitors} />
               <FaHome className="footer-icon" onClick={handleNavigateToVisitors} />
               <FaBell className="footer-icon" />
             </div>
           )}
       </Modal>
       
        )}
      </ScrollView>
   
    </View>
    <div className="footer">
      <FaBell className="footer-icon" />
      <FaHome className="footer-icon" onClick={() => navigate('/Visitors')}/>
      <FaPowerOff className="footer-icon" onClick={handleLogout} />
    </div>
    </div>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
  },
  scrollContainer: {
    flexGrow: 1,
    padding: 20,
    marginTop: 0, // Added to account for the fixed navbar height
    paddingBottom: 50, // Added to account for the fixed footer height
  },
  buttonSubmit: {
    backgroundColor: 'rgb(126 24 24)',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  timeContainer: {
    alignItems: 'flex-start',
   
    marginBottom: 20,
    backgroundColor: 'rgb(239 239 239)',
  },
  timeContainerdiv:{
    marginLeft:20,
  },
  timeText: {
    fontSize: 12,
  },
  select :{
  marginBottom:15,
  },
  cardContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
    marginTop:-20,
  },
  card: {
    width: '45%',
    padding: 5,
    backgroundColor: '#fff',
    borderRadius: 10,
    alignItems: 'center',
    shadowColor: '#000', // Black shadow color
    shadowOffset: { width: 0, height: 1 }, // Offset for the shadow
    shadowOpacity: 0.4, // Opacity for the shadow
    shadowRadius: 1.41, // Radius for the shadow blur
    elevation: 2, // Elevation for Android shadow
  },
  cardTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 10,
  }, 
  cardValue: {
    fontSize: 18,
  },
  visitorCard: {
    flexDirection: 'row',
    padding: 10,
    marginBottom: 10,
    backgroundColor: '#fff',
    borderRadius: 10,
    alignItems: 'center',
    shadowColor: '#000', // Black shadow color
    shadowOffset: { width: 0, height: 1 }, // Offset for the shadow
    shadowOpacity: 0.4, // Opacity for the shadow
    shadowRadius: 1.41, // Radius for the shadow blur
    elevation: 2, // Elevation for Android shadow
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 15,
    
  },
  info: {
    flex: 1,
  },
  visitorTitle: {
    fontSize: 18,
    // marginBottom: 5,
  },
  text: {
    fontSize: 14,
    // color:'gray',
  },
  dateStatusRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  textStatus: {
    fontSize: 14,
    textAlign: 'right', 
    // marginTop:-20,
  },
  textName: {
    fontSize: 16,
  },
  
  textdate: {
    fontSize: 14,
    color:'#818589',
  },
  noVisitorsCard: {
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 6,
    alignItems: 'center',
    marginTop: 20,
    shadowColor: '#000', // Black shadow color
    shadowOffset: { width: 0, height: 1 }, // Offset for the shadow
    shadowOpacity: 0.4, // Opacity for the shadow
    shadowRadius: 1.41, // Radius for the shadow blur
    elevation: 2, // Elevation for Android shadow
  },
  noVisitorsText: {
    fontSize: 14,
    color: '#888',
  },
  modalScrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalHeader: {
    backgroundColor: 'rgb(224 224 225)', // Purple background
    padding: 30,
    width: '90%',
    alignItems: 'center',
    // marginTop:0,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  modalContainer: {
    width: '90%',
    padding: 20,
    backgroundColor: 'rgb(224 224 225)',
    borderRadius: 10,
    marginTop: -30, // Overlap the modal header
    borderTopLeftRadius: 0,
    borderTopRightRadius: 0,
    
  },
  modalTitle: {
    fontSize: 24,
    marginBottom: 20,
    textAlign: 'center',
  },
  modalAvatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 0,
    marginTop:-70,
  },
  form: {
    width: '100%',
  },
  input: {
    width: '100%',
    padding: 8,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 4,
    backgroundColor:'#fff',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  errorText: {
    color: 'red',
    marginBottom: 8,
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
    marginTop:10,
    // 
  },
 
  button: {
    backgroundColor: 'rgb(126, 24, 24)', // Change the background color to red
    color: '#fff', // Change the text color to white
    padding: 10,
    borderRadius: 5,
    borderWidth: 0,
  },
  buttonDisabled: {
    backgroundColor: '#f0f0f0', // Light gray for disabled buttons
    color: '#ccc', // Gray text for disabled buttons
    padding: 10,
    borderRadius: 5,
    borderWidth: 0,
  },
});

export default Visitors;
